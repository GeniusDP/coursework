package org.example;

public class Calculator {

  public static int plus(int a, int b) {
    return a + b;
  }

  public static int minus(int a, int b) {
    return a - b;
  }

  public static int mult(int a, int b) {
    return a * b;
  }

  public static int div(int a, int b) {
    return a / b;
  }

}
